from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor,
from pybricks.parameters import Button, Color, Direction, Port, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub
color_scanner = ColorSensor(Port.C)

while True:
    detected = color_scanner.color()
    reflection = color_scanner.color()

    if detected == Color.YELLOW:
        print("YELLOW", reflection)

    elif detected == Color.WHITE:
        print("WHITE", reflection)

    elif detected == Color.BLUE:
        print("BLUE", reflection)

    elif detected == Color.GREEN:
        print("GREEN", reflection)

    else:
        print ("Turunkan Wowo")

    wait(800)

